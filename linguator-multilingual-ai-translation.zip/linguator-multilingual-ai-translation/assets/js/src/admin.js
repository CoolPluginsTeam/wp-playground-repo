/**
 * @package Linguator
 */

import { ajaxFilter } from './lib/ajax-filter/index.js';

ajaxFilter( lmat_admin?.ajax_filter );
