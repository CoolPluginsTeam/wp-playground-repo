<?php return array('dependencies' => array('react', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-rich-text'), 'version' => '882372900d1044a2ad43');
