<?php
/**
 * Wizard page rendered as proper WordPress admin page
 *
 * @package Linguator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wrap lmat-styles">
	<div id="lmat-setup"></div>
</div>
