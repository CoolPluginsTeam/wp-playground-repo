const StringPopUpNotice = (props) => {
    return (
        <div className={props.className}>{props.children}</div>
    );
}

export default StringPopUpNotice;