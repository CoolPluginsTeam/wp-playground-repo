import { useEffect, useState } from "react";
import FilterTargetContent from "../component/filter-target-content/index.js";
import { __ } from "@wordpress/i18n";
import { select } from "@wordpress/data";
import { Fragment } from "@wordpress/element";
import TranslateService from "../component/translate-provider/index.js";

const StringPopUpBody = (props) => {

    const { service: service } = props;
    const translateContent = select("block-lmatPageTranslation/translate").getTranslationEntry();
    const StringModalBodyNotice = props.stringModalBodyNotice;

    useEffect(() => {

        if (['yandex', 'google'].includes(props.service)) {
            document.documentElement.setAttribute('translate', 'no');
            document.body.classList.add('notranslate');
        }

        /**
         * Calls the translate service provider based on the service type.
         * For example, it can call services like yandex Translate.
        */
        const service = props.service;
        const id = `lmat_page_translation_${service}_translate_element`;

        const translateContent = wp.data.select('block-lmatPageTranslation/translate').getTranslationEntry();

        if (translateContent.length > 0 && props.postDataFetchStatus) {
            const ServiceSetting = TranslateService({ Service: service });
            ServiceSetting.Provider({ sourceLang: props.sourceLang, targetLang: props.targetLang, translateStatusHandler: props.translateStatusHandler, ID: id, translateStatus: props.translateStatus, modalRenderId: props.modalRender, destroyUpdateHandler: props.updateDestroyHandler });
        }
    }, [props.modalRender, props.postDataFetchStatus]);

    return (
        <div className="modal-body">
            {translateContent.length > 0 && props.postDataFetchStatus ?
                <>
                    {StringModalBodyNotice && <div className="lmat-page-translation-body-notice-wrapper"><StringModalBodyNotice /></div>}
                    <div className="lmat_page_translation_translate_progress" key={props.modalRender}>{__("Automatic translation is in progress....", 'linguator-multilingual-ai-translation')}<br />{__("It will take few minutes, enjoy ☕ coffee in this time!", 'linguator-multilingual-ai-translation')}<br /><br />{__("Please do not leave this window or browser tab while translation is in progress...", 'linguator-multilingual-ai-translation')}</div>
                    <div className={`translator-widget ${service}`} style={{ display: 'flex' }}>
                        <h3 className="choose-lang">{TranslateService({ Service: props.service }).heading} <span className="dashicons-before dashicons-translation"></span></h3>

                        <div className={`lmat_page_translation_translate_element_wrapper ${props.translateStatus ? 'translate-completed' : ''}`}>
                            <div id={`lmat_page_translation_${props.service}_translate_element`}></div>
                        </div>
                    </div>

                    <div className="lmat_page_translation_string_container">
                        <table className="scrolldown" id="stringTemplate">
                            <thead>
                                <tr>
                                    <th className="notranslate">{__("S.No", 'linguator-multilingual-ai-translation')}</th>
                                    <th className="notranslate">{__("Source Text", 'linguator-multilingual-ai-translation')}</th>
                                    <th className="notranslate">{__("Translation", 'linguator-multilingual-ai-translation')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {props.postDataFetchStatus &&
                                    <>
                                        {translateContent.map((data, index) => {
                                            return (
                                                <Fragment key={index + props.translatePendingStatus}>
                                                    {undefined !== data.source && data.source.trim() !== '' &&
                                                        <>
                                                            <tr key={index + 'tr' + props.translatePendingStatus}>
                                                                <td>{index + 1}</td>
                                                                <td data-source="source_text">{data.source}</td>
                                                                {!props.translatePendingStatus ?
                                                                        <td className="translate" data-translate-status="translated" data-key={data.id} data-string-type={data.type}>{data.translatedData[props.service]}</td> :
                                                                        <td className="translate" translate="yes" data-key={data.id} data-string-type={data.type}>
                                                                            <FilterTargetContent service={props.service} content={data.source} contentKey={data.id} />
                                                                        </td>
                                                                }
                                                            </tr>
                                                        </>
                                                    }
                                                </Fragment>
                                            );
                                        })
                                        }
                                    </>
                                }
                            </tbody>
                        </table>
                    </div>
                </> :
                props.postDataFetchStatus ?
                    <p>{__('No strings are available for translation', 'linguator-multilingual-ai-translation')}</p> :

                    <div className="lmat-page-translation-skeleton-loader-wrapper">
                        <div className="translate-widget">
                            <div className="lmat-page-translation-skeleton-loader-mini"></div>
                            <div className="lmat-page-translation-skeleton-loader-mini"></div>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <th className="notranslate">{__("S.No", 'linguator-multilingual-ai-translation')}</th>
                                    <th className="notranslate">{__("Source Text", 'linguator-multilingual-ai-translation')}</th>
                                    <th className="notranslate">{__("Translation", 'linguator-multilingual-ai-translation')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {[...Array(10)].map((_, index) => {
                                    return (
                                        <tr key={index}>
                                            <td><div className="lmat-page-translation-skeleton-loader-mini"></div></td>
                                            <td><div className="lmat-page-translation-skeleton-loader-mini"></div></td>
                                            <td><div className="lmat-page-translation-skeleton-loader-mini"></div></td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
            }
        </div>
    );
}

export default StringPopUpBody;
