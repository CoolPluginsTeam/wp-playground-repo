<?php
/**
 * @package Linguator
 */
namespace Linguator\Integrations\twenty_seventeen;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Linguator\Includes\Options\LMAT_Translate_Option;
use Linguator\Frontend\Controllers\LMAT_Frontend;



/**
 * Manages the compatibility with Twenty_Seventeen.
 *
 *  
 */
class LMAT_Twenty_Seventeen {
	/**
	 * Translates the front page panels and the header video.
	 *
	 *  
	 */
	public function init() {
		if ( 'twentyseventeen' === get_template() && did_action( 'lmat_init' ) ) {
			if ( function_exists( 'twentyseventeen_panel_count' ) && LMAT() instanceof LMAT_Frontend ) {
				$num_sections = twentyseventeen_panel_count();
				for ( $i = 1; $i < ( 1 + $num_sections ); $i++ ) {
					add_filter( 'theme_mod_panel_' . $i, 'lmat_get_post' );
				}
			}

			$theme_slug = get_option( 'stylesheet' ); // In case we are using a child theme.
			new LMAT_Translate_Option( "theme_mods_$theme_slug", array( 'external_header_video' => 1 ), array( 'context' => 'Twenty Seventeen' ) );
		}
	}
}
