=== Linguator – Multilingual AI Translation (beta) ===
Contributors: narinder-singh,satindersingh,coolplugins
Tags: translation, multilingual, language, ai translation 
Requires at least: 6.2
Tested up to: 6.8.3
Requires PHP: 7.2
Stable tag: 0.0.4  (beta) 
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Translate your WordPress website into multiple languages with AI. Linguator makes creating multilingual sites simple, fast, and SEO-friendly.

== Description ==

**Linguator**  is a powerful multilingual plugin that helps you create and manage multilingual content on your WordPress website. Easily translate your **posts, pages, menus,** and **categories** into different languages using AI and connect with visitors worldwide.
### Create Multilingual Sites - Smarter, Faster, and Easier.

https://youtu.be/dst_bf7uiTc?si=_RUgFIrJ121JSPrM

https://youtu.be/20MbjUb6AnM?si=-1qipV1fFH89KtgT

Demo Access: [Check Live Preview](https://linguator-demo-site.instawp.co/wp-admin/admin.php?page=lmat_settings)
Username: demo
Password: demo
**This demo is for preview purposes only — any data entered will not be save**

### Why Use Linguator?
Linguator makes it simple to create and manage multilingual websites directly inside WordPress. With Linguator, you can:

* **Save time with AI-powered translation**
* **Increase reach and global visibility**
* **Build trust with localized content**

### Key Features
* **AI-Powered Automatic Translation:**  **Save hours of manual work!** Linguator uses powerful AI translation engines to automatically translate your posts and pages into multiple languages — giving you high-quality, natural translations in one click.
* **SEO-Friendly Multilingual URLs:** Each language gets its own unique, SEO-friendly URL structure — helping your site rank better in Google for multiple languages and attract global visitors.

* **Manual + Automatic Translation Control:** Translate your content automatically using AI, or fine-tune it manually for complete accuracy — Linguator gives you both options for full flexibility.

* **Add & Manage Languages:** Without any limit on the number of languages, translate your WordPress website content into multiple languages.

* **Elementor Page Translation:** Translate entire Elementor pages, including all sections, widgets, and content, without losing styles or design.
* **Gutenberg Block Compatibility:** Automatically translate content within Gutenberg blocks, including core blocks and popular third-party blocks like Spectra, Kadence, Stackable, Otter, and Essential.

* **Bulk Translation:** Instantly translate multiple posts, pages, or products at once with a single click, saving time and effort.
* **Inline Translation:** Translate specific widgets or blocks of content directly within the editor, without translating the entire page, using advanced AI-powered translation tools.

* **Custom Post Type Translation:** If your site uses custom post types **(like "Events", "Portfolios", "Testimonials", etc.)**, using Linguator, you can translate all of them.

* **Media Translation Management:** Translate image titles, captions, alt text, and descriptions to match each language.
* **Menu Translation:** Create separate navigation menus per language and let visitors switch between them.
* **Taxonomy Translation:** Linguator plugin supports the translation of default WordPress taxonomies (like categories and tags) or custom ones, ensuring content stays organized in every language.

* **Language Switcher:** Add a language switcher to your site with multiple display options, including Classic, Block-based, and Elementor widget styles, to easily switch languages.

* **RTL Language Support:** Linguator offers full support for right-to-left (RTL) languages like Arabic and Hebrew. It automatically adjusts text direction, alignment, and layout to ensure your multilingual site displays correctly in every supported language.

* **Browser Language Detection:** Automatically display your site in the visitor's preferred language based on their browser settings.

* **Supports Popular Page Builders:** Linguator works smoothly with page builders like Elementor and Gutenberg — making it easy to translate visually designed pages without breaking layouts.

> **Note:** Linguator is currently in **Beta**, and we’re actively improving features and performance based on user feedback.

 == Screenshots ==

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/linguator-multilingual-ai-translation` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Use the **Linguator > Settings** screen to configure the plugin.
4. Follow the setup wizard to configure your languages.

> **Note:** Linguator is currently in **Beta**, and we’re actively improving features and performance based on user feedback.


== Frequently Asked Questions ==

= Which languages are supported? =
Linguator supports all languages that WordPress supports, including RTL languages.

= Is it compatible with all WordPress themes? =
Yes, Linguator is designed to work with any properly coded WordPress theme.

= Does it work with Elementor and Gutenberg? =
Yes, the Linguator plugin fully supports the translation of page editors like Gutenberg and Elementor. You can translate your content directly within these editors.

= Can I create different menus for each language? =
Yes. You can create and manage separate navigation menus for each language and let visitors switch between them.

= Where can I place the Language Switcher on my site? =
You can place it in menus, sidebars, headers, footers, or any widget-ready area. If you use Elementor, you can add it directly to your page or template using the Elementor widget.

= Can I translate media, such as images and videos? =
Yes. Linguator allows you to translate media metadata, including image titles, alt text, captions, and descriptions, ensuring your content is fully localized.

= Can it detect the visitor's browser language? =
Yes. Linguator includes an option to automatically detect the visitor's browser language and display the site in that language.

= How many languages can I add with Linguator? =
There is no limit. You can add as many languages as you want to your website using Linguator.

= How can I report security bugs? =
You can report security bugs through the Patchstack Vulnerability Disclosure Program. The Patchstack team help validate, triage, and handle any security vulnerabilities. [Report a security vulnerability](https://patchstack.com/database/wordpress/plugin/linguator-multilingual-ai-translation/vdp).

=Is Linguator still in beta? =
Yes, Linguator is currently in its beta stage. This means the core features are ready to use, but we’re still improving stability, performance, and adding more integrations based on user feedback.

== Changelog ==
> **Note:** Linguator is currently in **Beta**, and we’re actively improving features and performance based on user feedback.

= Version 0.0.4 (Beta) | 08/10/2025 =
* **Added:-**  **AI Translation System** Multiple translation providers support (Chrome AI /Google Machine Translation).
* **Added:-**  Custom Field Translation Management Panel support
* **Added:-**  **Bulk Translation** Mass (pages/posts)  content translation.
* **Added:-**  Real-time editor translation.
* **Added:-**  Advanced Content Filters based on languages.
* **Added:-**  **Menu Filter** Advanced menu filtering and management.
* **Added:-**  **Performance Optimization** Enhanced caching and speed.
* **Improved:-** Default status(draft/publish)settings of translated pages and posts
* **Improved:-** Improved overall settings panel
* **Improved:-** Improved overall codes and admin styles.

=  Version 0.0.3  (Beta) | 05/09/2025 =
* Fixed escaping and sanitization issues.
* Minor bug fixes.

=  Version 0.0.2   (Beta) | 02/08/2025 =
* Fixed issue with translated strings.
* Fixed Minor issues.

=  Version 0.0.1   (Beta) | 07/06/2025 =
* Initial release with core multilingual features for WP approval 

== Upgrade Notice ==
Initial release on WP.org repo.
